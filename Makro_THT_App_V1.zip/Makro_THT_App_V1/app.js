import { initializeApp } from "https://www.gstatic.com/firebasejs/12.2.1/firebase-app.js";
import {
  getFirestore, collection, addDoc, deleteDoc, doc, onSnapshot,
  query, orderBy, serverTimestamp, enableIndexedDbPersistence
} from "https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js";

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
enableIndexedDbPersistence(db).catch(() => {});

const $ = (id) => document.getElementById(id);
const form = $("productForm");
const preview = $("preview");
let photoData = "";
let products = [];
let scannerStream = null;
let scannerTimer = null;

const placeholder = "data:image/svg+xml;charset=UTF-8," + encodeURIComponent(`<svg xmlns='http://www.w3.org/2000/svg' width='200' height='200'><rect width='100%' height='100%' fill='#eeeeee'/><text x='50%' y='50%' text-anchor='middle' dominant-baseline='middle' fill='#777' font-family='Arial' font-size='18'>Geen foto</text></svg>`);

$("photo").addEventListener("change", async (event) => {
  const file = event.target.files?.[0];
  if (!file) return;
  try {
    photoData = await compressImage(file, 520, 0.62);
    preview.src = photoData;
    preview.classList.remove("hidden");
  } catch (error) {
    showMessage("Foto kon niet worden verwerkt.", true);
  }
});

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const name = $("productName").value.trim();
  const expiryDate = $("expiryDate").value;
  if (!name || !expiryDate) return showMessage("Vul productnaam en THT in.", true);
  $("saveBtn").disabled = true;
  showMessage("Bezig met opslaan…");
  try {
    await addDoc(collection(db, "thtRegistraties"), {
      barcode: $("barcode").value.trim(),
      productName: name,
      expiryDate,
      quantity: Number($("quantity").value || 0),
      location: $("location").value,
      note: $("note").value.trim(),
      photo: photoData,
      createdAt: serverTimestamp()
    });
    form.reset();
    $("quantity").value = 1;
    photoData = "";
    preview.src = "";
    preview.classList.add("hidden");
    showMessage("Product is opgeslagen.");
  } catch (error) {
    console.error(error);
    showMessage("Opslaan mislukt. Controleer internet en Firestore-regels.", true);
  } finally {
    $("saveBtn").disabled = false;
  }
});

const productQuery = query(collection(db, "thtRegistraties"), orderBy("expiryDate", "asc"));
onSnapshot(productQuery, (snapshot) => {
  products = snapshot.docs.map((d) => ({ id: d.id, ...d.data() }));
  renderAll();
}, (error) => {
  console.error(error);
  $("productList").innerHTML = `<div class="card">Database kon niet worden gelezen. Controleer de Firestore Rules.</div>`;
});

function renderAll() {
  updateStats();
  renderList();
  renderUrgent();
}

function statusFor(dateString) {
  const today = new Date(); today.setHours(0,0,0,0);
  const date = new Date(dateString + "T00:00:00");
  const days = Math.ceil((date - today) / 86400000);
  if (days < 0) return { key:"expired", label:`Verlopen (${Math.abs(days)} d.)`, days };
  if (days <= 30) return { key:"soon", label: days === 0 ? "Vandaag" : `${days} dagen`, days };
  return { key:"good", label:`${days} dagen`, days };
}

function updateStats() {
  let expired=0, soon=0, good=0;
  products.forEach((p) => { const s=statusFor(p.expiryDate).key; if(s==="expired") expired++; else if(s==="soon") soon++; else good++; });
  $("countAll").textContent = products.length;
  $("countExpired").textContent = expired;
  $("count30").textContent = soon;
  $("countGood").textContent = good;
}

function renderList() {
  const term = $("search").value.trim().toLowerCase();
  const filter = $("statusFilter").value;
  const filtered = products.filter((p) => {
    const matches = !term || `${p.productName||""} ${p.barcode||""}`.toLowerCase().includes(term);
    const status = statusFor(p.expiryDate).key;
    return matches && (filter === "all" || filter === status);
  });
  drawProducts($("productList"), filtered);
}

function renderUrgent() {
  drawProducts($("urgentList"), products.filter((p) => statusFor(p.expiryDate).key !== "good"));
}

function drawProducts(container, list) {
  container.innerHTML = "";
  if (!list.length) {
    container.innerHTML = `<div class="card">Geen producten gevonden.</div>`;
    return;
  }
  const template = $("productTemplate");
  list.forEach((p) => {
    const node = template.content.cloneNode(true);
    const status = statusFor(p.expiryDate);
    node.querySelector(".product-photo").src = p.photo || placeholder;
    node.querySelector(".product-title").textContent = p.productName || "Zonder naam";
    node.querySelector(".product-meta").textContent = `Barcode: ${p.barcode || "—"} • Aantal: ${p.quantity ?? 0}`;
    node.querySelector(".product-expiry").textContent = `THT: ${formatDate(p.expiryDate)}`;
    node.querySelector(".product-location").textContent = `Locatie: ${p.location || "—"}${p.note ? ` • ${p.note}` : ""}`;
    const pill = node.querySelector(".status-pill");
    pill.textContent = status.label;
    pill.classList.add(`status-${status.key}`);
    node.querySelector(".delete-btn").addEventListener("click", async () => {
      if (confirm(`Verwijder ${p.productName}?`)) await deleteDoc(doc(db, "thtRegistraties", p.id));
    });
    container.appendChild(node);
  });
}

$("search").addEventListener("input", renderList);
$("statusFilter").addEventListener("change", renderList);

document.querySelectorAll(".tab").forEach((button) => button.addEventListener("click", () => {
  document.querySelectorAll(".tab").forEach((b) => b.classList.toggle("active", b === button));
  document.querySelectorAll(".view").forEach((v) => v.classList.remove("active"));
  $(`view-${button.dataset.view}`).classList.add("active");
}));

$("exportBtn").addEventListener("click", () => {
  const rows = [["Foto aanwezig","Barcode","Productnaam","THT","Aantal","Locatie","Status","Opmerking"]];
  products.forEach((p) => rows.push([
    p.photo ? "Ja" : "Nee", p.barcode || "", p.productName || "", p.expiryDate || "",
    p.quantity ?? "", p.location || "", statusFor(p.expiryDate).label, p.note || ""
  ]));
  const csv = "\ufeff" + rows.map((r) => r.map(csvCell).join(";")).join("\r\n");
  const blob = new Blob([csv], { type:"text/csv;charset=utf-8" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `Makro_THT_${new Date().toISOString().slice(0,10)}.csv`;
  a.click();
  URL.revokeObjectURL(a.href);
});

function csvCell(value) { return `"${String(value).replaceAll('"','""')}"`; }
function formatDate(value) { if(!value) return "—"; const [y,m,d]=value.split("-"); return `${d}-${m}-${y}`; }
function showMessage(text, error=false) { const el=$("formMessage"); el.textContent=text; el.style.color=error?"#b42318":"#027a48"; }

async function compressImage(file, maxSize, quality) {
  const bitmap = await createImageBitmap(file);
  const scale = Math.min(1, maxSize / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(bitmap.width * scale));
  canvas.height = Math.max(1, Math.round(bitmap.height * scale));
  canvas.getContext("2d").drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  return canvas.toDataURL("image/jpeg", quality);
}

$("scanBtn").addEventListener("click", startScanner);
$("closeScanner").addEventListener("click", stopScanner);

async function startScanner() {
  if (!("BarcodeDetector" in window)) {
    alert("Automatisch scannen wordt niet ondersteund op deze browser. Typ de barcode handmatig.");
    return;
  }
  try {
    const detector = new BarcodeDetector({ formats:["ean_13","ean_8","upc_a","upc_e","code_128","code_39"] });
    scannerStream = await navigator.mediaDevices.getUserMedia({ video:{ facingMode:{ ideal:"environment" } }, audio:false });
    $("scannerVideo").srcObject = scannerStream;
    await $("scannerVideo").play();
    $("scannerDialog").showModal();
    scannerTimer = setInterval(async () => {
      try {
        const codes = await detector.detect($("scannerVideo"));
        if (codes.length) {
          $("barcode").value = codes[0].rawValue;
          stopScanner();
        }
      } catch (_) {}
    }, 400);
  } catch (error) {
    alert("Camera kon niet worden geopend. Geef Chrome toestemming voor de camera.");
  }
}

function stopScanner() {
  clearInterval(scannerTimer); scannerTimer=null;
  scannerStream?.getTracks().forEach((t) => t.stop()); scannerStream=null;
  if ($("scannerDialog").open) $("scannerDialog").close();
}

let installPrompt;
window.addEventListener("beforeinstallprompt", (event) => {
  event.preventDefault(); installPrompt=event; $("installBtn").classList.remove("hidden");
});
$("installBtn").addEventListener("click", async () => {
  if (!installPrompt) return;
  installPrompt.prompt(); await installPrompt.userChoice; installPrompt=null; $("installBtn").classList.add("hidden");
});

if ("serviceWorker" in navigator) navigator.serviceWorker.register("./service-worker.js");
