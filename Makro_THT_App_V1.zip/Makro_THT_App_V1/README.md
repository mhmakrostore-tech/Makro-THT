# Makro THT App – versie 1

Functies:
- Productfoto maken op telefoon
- Barcode automatisch scannen waar Chrome dit ondersteunt
- Productnaam, THT, aantal en locatie opslaan
- Synchronisatie via Cloud Firestore
- Verlopen/binnen 30 dagen/goed overzicht
- Zoeken en filteren
- Excel/CSV-export
- Installeerbaar als webapp op Android

## Belangrijk voor Firebase
1. Firestore Database moet actief zijn.
2. Plaats de inhoud van `firestore.rules` in Firestore > Rules en klik Publish.
3. Zet de website online via Firebase Hosting of een andere HTTPS-host. Camera en installatie werken alleen goed via HTTPS.

## GitHub upload
Pak de ZIP uit. Klik in je GitHub repository op Add file > Upload files en sleep alle uitgepakte bestanden naar het uploadvak.
