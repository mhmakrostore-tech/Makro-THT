// Firebase-configuratie van het project Makro THT.
export const firebaseConfig = {
  apiKey: "AIzaSyAz84bwA97vvqv7LrjvYXB17BheRwGM_ms",
  authDomain: "makro-tht.firebaseapp.com",
  projectId: "makro-tht",
  storageBucket: "makro-tht.firebasestorage.app",
  messagingSenderId: "777366139530",
  appId: "1:777366139530:web:2cc8ca4c2dffb9e07f373",
  measurementId: "G-K9SV5ZLM83"
};
